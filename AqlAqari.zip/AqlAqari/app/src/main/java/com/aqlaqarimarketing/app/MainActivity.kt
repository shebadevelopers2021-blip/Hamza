package com.aqlaqarimarketing.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

private val Green = Color(0xFF167D68)
private val Ink = Color(0xFF172B27)
private val Soft = Color(0xFFF3F7F5)

class MainActivity : ComponentActivity() {
    private lateinit var db: LocalDb
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = LocalDb(this)
        setContent { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { AppRoot(db, ::openWhatsApp) } }
    }
    private fun openWhatsApp(phone: String, message: String) {
        try {
            if (phone.isBlank()) {
                val share = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, message) }
                startActivity(Intent.createChooser(share, "مشاركة الإعلان"))
                return
            }
            val clean = phone.filter { it.isDigit() || it == '+' }.removePrefix("+")
            if (clean.isBlank()) { Toast.makeText(this,"أدخل رقم هاتف صحيحاً",Toast.LENGTH_SHORT).show(); return }
            val encoded = URLEncoder.encode(message, StandardCharsets.UTF_8.toString())
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$clean?text=$encoded")))
        } catch (_: Exception) { Toast.makeText(this,"تعذر فتح تطبيق المشاركة أو واتساب",Toast.LENGTH_LONG).show() }
    }
}

@Composable
private fun AppRoot(db: LocalDb, send: (String,String)->Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    var showAd by remember { mutableStateOf(false) }
    var showPerson by remember { mutableStateOf(false) }
    val ads = remember(refresh) { db.ads() }
    val people = remember(refresh) { db.people() }
    val patterns = remember(refresh) { db.patterns() }
    MaterialTheme(colorScheme = lightColorScheme(primary=Green, secondary=Color(0xFFB78A42), background=Soft, surface=Color.White)) {
        Scaffold(
            containerColor = Soft,
            topBar = { Column(Modifier.fillMaxWidth().background(Color.White).padding(horizontal=20.dp, vertical=16.dp)) {
                Text("العقل العقاري",fontSize=23.sp,fontWeight=FontWeight.Bold,color=Ink)
                Text("إدارة الإعلانات والتوزيع العقاري",fontSize=12.sp,color=Color.Gray)
            } },
            floatingActionButton = {
                if (tab==1 || tab==2) FloatingActionButton(onClick={ if(tab==1) showAd=true else showPerson=true },containerColor=Green,contentColor=Color.White) { Icon(Icons.Default.Add,contentDescription="إضافة") }
            },
            bottomBar = { NavigationBar(containerColor=Color.White) {
                val names=listOf("الرئيسية","الإعلانات","المستلمون","الأنماط","الجدولة")
                val icons=listOf(Icons.Default.Dashboard,Icons.Default.Campaign,Icons.Default.People,Icons.Default.Style,Icons.Default.Schedule)
                names.forEachIndexed { i,n -> NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(icons[i],contentDescription=n)},label={Text(n,fontSize=10.sp)}) }
            } }
        ) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=16.dp)) {
                Spacer(Modifier.height(12.dp))
                when(tab) {
                    0 -> Dashboard(db, ads.size, people.size, patterns.size) { tab=1 }
                    1 -> AdsScreen(ads, send, db) { refresh++ }
                    2 -> PeopleScreen(people) { id -> db.deletePerson(id);refresh++ }
                    3 -> PatternsScreen(patterns)
                    else -> ScheduleScreen()
                }
            }
        }
        if(showAd) AdDialog(onDismiss={showAd=false},onSave={ a -> db.addAd(a);refresh++;showAd=false })
        if(showPerson) PersonDialog(onDismiss={showPerson=false},onSave={ p -> db.addPerson(p);refresh++;showPerson=false })
    }
}

@Composable private fun Dashboard(db: LocalDb, adCount:Int, peopleCount:Int, patternCount:Int, goAds:()->Unit) {
    Text("مرحباً بك",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink)
    Text("ملخص نشاطك العقاري",color=Color.Gray,fontSize=13.sp)
    Spacer(Modifier.height(16.dp))
    Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        MetricCard("الإعلانات",adCount.toString(),Icons.Default.Campaign,Modifier.weight(1f))
        MetricCard("المستلمون",peopleCount.toString(),Icons.Default.People,Modifier.weight(1f))
    }
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        MetricCard("الأنماط",patternCount.toString(),Icons.Default.Style,Modifier.weight(1f))
        MetricCard("سجلات الفتح",db.logsCount().toString(),Icons.Default.Send,Modifier.weight(1f))
    }
    Spacer(Modifier.height(18.dp))
    Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFE5F1ED)),shape=RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text("ابدأ بإعلانك التالي",fontWeight=FontWeight.Bold,color=Ink,fontSize=17.sp)
            Text("أضف تفاصيل العقار ثم جهّز نص الإعلان وشاركه مع المستلمين.",color=Color(0xFF52635D),fontSize=13.sp)
            Spacer(Modifier.height(12.dp))
            Button(onClick=goAds,colors=ButtonDefaults.buttonColors(containerColor=Green)) { Text("إدارة الإعلانات") }
        }
    }
    Spacer(Modifier.height(16.dp))
    Card(colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Text("معلومات مهمة",fontWeight=FontWeight.Bold,color=Ink)
            Spacer(Modifier.height(6.dp))
            Text("بياناتك محفوظة محلياً على الهاتف. مشاركة واتساب تفتح المحادثة والنص جاهز؛ يجب عليك الضغط على إرسال داخل واتساب.",fontSize=12.sp,color=Color.Gray)
        }
    }
}

@Composable private fun MetricCard(label:String,value:String,icon: androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier=Modifier) {
    Card(modifier=modifier.height(112.dp),colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.SpaceBetween) {
            Icon(icon,tint=Green,contentDescription=null)
            Row(verticalAlignment=Alignment.Bottom,horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()) {
                Text(label,color=Color.Gray,fontSize=12.sp);Text(value,color=Ink,fontSize=23.sp,fontWeight=FontWeight.Bold)
            }
        }
    }
}

@Composable private fun AdsScreen(ads:List<Ad>, send:(String,String)->Unit, db:LocalDb, changed:()->Unit) {
    Text("الإعلانات العقارية",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
    Text("أنشئ إعلاناً واحفظه ثم شاركه عند الحاجة",fontSize=12.sp,color=Color.Gray)
    Spacer(Modifier.height(12.dp))
    if(ads.isEmpty()) EmptyState("لا توجد إعلانات بعد","اضغط زر + لإضافة أول إعلان")
    LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=90.dp)) {
        items(ads,key={it.id}) { ad ->
            Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(ad.title,fontWeight=FontWeight.Bold,color=Ink,fontSize=16.sp);Text("${ad.type} • ${ad.location}",fontSize=12.sp,color=Color.Gray) }
                        TextButton(onClick={db.deleteAd(ad.id);changed()}) { Icon(Icons.Default.Delete,null,tint=Color(0xFFB34B4B)) }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("المساحة: ${ad.area.ifBlank { "غير محددة" }}   |   السعر: ${ad.price} ${ad.currency}",fontSize=12.sp,color=Color.DarkGray)
                    Text(ad.description, maxLines=2,fontSize=12.sp,color=Color.Gray)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick={send("",buildAdText(ad))},modifier=Modifier.weight(1f)) { Icon(Icons.Default.Share,null);Spacer(Modifier.width(5.dp));Text("مشاركة") }
                        Button(onClick={
                            val p=ad.contacts.split(",").firstOrNull()?.trim().orEmpty()
                            send(p,buildAdText(ad))
                            db.logSend(ad.id,p,"WhatsApp","تم فتح رابط المشاركة؛ الإرسال غير مؤكد")
                        },modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Green)) { Icon(Icons.Default.Message,null);Spacer(Modifier.width(5.dp));Text("واتساب") }
                    }
                }
            }
        }
    }
}
private fun buildAdText(a:Ad):String = listOf("🏡 ${a.title}","📍 الموقع: ${a.location}","📐 المساحة: ${a.area}","💰 السعر: ${a.price} ${a.currency}","🛣 الشارع: ${a.street}",a.description,"📞 للتواصل: ${a.contacts}").filter{it.isNotBlank()}.joinToString("\n")

@Composable private fun PeopleScreen(people:List<Person>,delete:(Long)->Unit) {
    Text("المستلمون والوسطاء",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
    Text("احفظ الأشخاص وأرقامهم لتجهيز التوزيع",fontSize=12.sp,color=Color.Gray)
    Spacer(Modifier.height(12.dp))
    if(people.isEmpty()) EmptyState("قائمة المستلمين فارغة","أضف الوسطاء والعملاء وأرقام التواصل")
    LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=90.dp)) {
        items(people,key={it.id}) { p -> Card(colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Person,color=Green,modifier=Modifier.size(32.dp),contentDescription=null)
                Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)) { Text(p.name,fontWeight=FontWeight.Bold,color=Ink);Text("${p.role} • ${p.phone}",fontSize=12.sp,color=Color.Gray) }
                IconButton(onClick={delete(p.id)}) { Icon(Icons.Default.Delete,null,tint=Color.Gray) }
            }
        } }
    }
}

@Composable private fun PatternsScreen(patterns:List<Pattern>) {
    Text("مكتبة الأنماط",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
    Text("تقسيم الإعلان إلى رأس وجسم وأطراف وفق الملف",fontSize=12.sp,color=Color.Gray)
    Spacer(Modifier.height(12.dp))
    LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) {
        items(patterns,key={it.id}) { p -> Card(colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(14.dp)) {
                Text(p.name,fontWeight=FontWeight.Bold,color=Ink,fontSize=16.sp)
                PatternPart("RA — رأس الإعلان",p.head,Color(0xFFE7EFF8))
                PatternPart("GA — جسم الإعلان",p.body,Color(0xFFE5F2ED))
                PatternPart("QA — أطراف الإعلان",p.footer,Color(0xFFF5EEDC))
            }
        } }
    }
}
@Composable private fun PatternPart(title:String,body:String,color:Color) { Column(Modifier.fillMaxWidth().padding(top=8.dp).background(color,RoundedCornerShape(10.dp)).padding(10.dp)) { Text(title,fontWeight=FontWeight.Bold,fontSize=12.sp);Text(body,fontSize=11.sp,color=Color.DarkGray) } }

@Composable private fun ScheduleScreen() {
    Text("الجدولة",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
    Spacer(Modifier.height(12.dp))
    Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Icon(Icons.Default.Schedule,tint=Green,modifier=Modifier.size(36.dp),contentDescription=null)
            Spacer(Modifier.height(8.dp))
            Text("الجدولة قيد الاستكمال",fontWeight=FontWeight.Bold,color=Ink,fontSize=17.sp)
            Text("هذه النسخة لا تنفذ إرسال واتساب في الخلفية ولا تنشئ مهام إرسال مؤجلة. يمكن استخدام تذكير الهاتف يدوياً إلى أن يكتمل محرك الجدولة ويُختبر.",fontSize=13.sp,color=Color.Gray)
        }
    }
}

@Composable private fun EmptyState(title:String,subtitle:String) { Box(Modifier.fillMaxWidth().padding(top=48.dp),contentAlignment=Alignment.Center) { Column(horizontalAlignment=Alignment.CenterHorizontally) { Icon(Icons.Default.Inbox,null,tint=Color.LightGray,modifier=Modifier.size(44.dp));Spacer(Modifier.height(10.dp));Text(title,fontWeight=FontWeight.Bold,color=Ink);Text(subtitle,fontSize=12.sp,color=Color.Gray) } } }

@Composable private fun AdDialog(onDismiss:()->Unit,onSave:(Ad)->Unit) {
    var title by remember { mutableStateOf("") };var type by remember { mutableStateOf("أرض") };var location by remember { mutableStateOf("") };var area by remember { mutableStateOf("") };var price by remember { mutableStateOf("") };var currency by remember { mutableStateOf("ريال سعودي") };var street by remember { mutableStateOf("") };var description by remember { mutableStateOf("") };var contacts by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text("إضافة إعلان عقاري",fontWeight=FontWeight.Bold)},text={
        Column(Modifier.fillMaxWidth().heightIn(max=520.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Field("عنوان الإعلان",title,{title=it});Field("الموقع",location,{location=it});Field("المساحة والأبعاد",area,{area=it});Field("السعر",price,{price=it},KeyboardType.Decimal)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { listOf("أرض","منزل","هنجر","تجاري","أخرى").forEach { FilterChip(selected=type==it,onClick={type=it},label={Text(it,fontSize=10.sp)}) } }
            Field("العملة",currency,{currency=it});Field("الشارع",street,{street=it});Field("الوصف والمميزات",description,{description=it},single=true);Field("أرقام التواصل (افصل بينها بفاصلة)",contacts,{contacts=it},KeyboardType.Phone)
        }
    },confirmButton={Button(onClick={if(title.isNotBlank()) onSave(Ad(0,title,type,location,area,price,currency,street,description,contacts,"متاح"))},enabled=title.isNotBlank(),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("حفظ الإعلان")}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})
}
@Composable private fun PersonDialog(onDismiss:()->Unit,onSave:(Person)->Unit) {
    var name by remember { mutableStateOf("") };var phone by remember { mutableStateOf("") };var role by remember { mutableStateOf("وسيط") };var notes by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text("إضافة مستلم")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Field("الاسم",name,{name=it});Field("رقم الهاتف مع رمز الدولة",phone,{phone=it},KeyboardType.Phone);Field("الصفة",role,{role=it});Field("ملاحظات",notes,{notes=it})}},confirmButton={Button(onClick={if(name.isNotBlank()&&phone.isNotBlank())onSave(Person(0,name,phone,role,notes))},enabled=name.isNotBlank()&&phone.isNotBlank()){Text("حفظ")}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})
}
@Composable private fun Field(label:String,value:String,onValue:(String)->Unit,kb:KeyboardType=KeyboardType.Text,single:Boolean=false) {
    OutlinedTextField(value=value,onValueChange=onValue,label={Text(label,fontSize=12.sp)},modifier=Modifier.fillMaxWidth(),singleLine=!single,minLines=if(single)2 else 1,keyboardOptions=KeyboardOptions(keyboardType=kb))
}
