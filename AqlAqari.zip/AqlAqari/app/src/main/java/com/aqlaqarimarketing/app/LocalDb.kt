package com.aqlaqarimarketing.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

 data class Ad(val id: Long, val title: String, val type: String, val location: String, val area: String, val price: String, val currency: String, val street: String, val description: String, val contacts: String, val status: String)
 data class Person(val id: Long, val name: String, val phone: String, val role: String, val notes: String)
 data class Pattern(val id: Long, val name: String, val head: String, val body: String, val footer: String)

class LocalDb(context: Context) : SQLiteOpenHelper(context, "aqlaqarimarketing.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE ads(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,type TEXT,location TEXT,area TEXT,price TEXT,currency TEXT,street TEXT,description TEXT,contacts TEXT,status TEXT,created_at INTEGER)")
        db.execSQL("CREATE TABLE people(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT NOT NULL,role TEXT,notes TEXT)")
        db.execSQL("CREATE TABLE patterns(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,head TEXT,body TEXT,footer TEXT)")
        db.execSQL("CREATE TABLE send_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,ad_id INTEGER,recipient TEXT,channel TEXT,status TEXT,created_at INTEGER)")
        db.execSQL("CREATE TABLE schedules(id INTEGER PRIMARY KEY AUTOINCREMENT,ad_id INTEGER,recipient TEXT,scheduled_at INTEGER,status TEXT)")
        db.execSQL("INSERT INTO patterns(name,head,body,footer) VALUES('النمط الأساسي','🏡 عرض عقاري مميز','📍 الموقع: {location}\\n📐 المساحة: {area}\\n💰 السعر: {price} {currency}\\n🛣 الشارع: {street}\\n{description}','للتواصل: {contacts}')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun addAd(a: Ad): Long = writableDatabase.insert("ads", null, ContentValues().apply {
        put("title",a.title); put("type",a.type); put("location",a.location); put("area",a.area); put("price",a.price); put("currency",a.currency); put("street",a.street); put("description",a.description); put("contacts",a.contacts); put("status",a.status); put("created_at",System.currentTimeMillis())
    })
    fun ads(): List<Ad> = readableDatabase.rawQuery("SELECT * FROM ads ORDER BY id DESC", null).use { c -> buildList { while(c.moveToNext()) add(Ad(c.getLong(0),c.getString(1)?:"",c.getString(2)?:"",c.getString(3)?:"",c.getString(4)?:"",c.getString(5)?:"",c.getString(6)?:"",c.getString(7)?:"",c.getString(8)?:"",c.getString(9)?:"",c.getString(10)?:"")) } }
    fun deleteAd(id: Long) { writableDatabase.delete("ads","id=?", arrayOf(id.toString())) }
    fun addPerson(p: Person): Long = writableDatabase.insert("people",null,ContentValues().apply { put("name",p.name);put("phone",p.phone);put("role",p.role);put("notes",p.notes) })
    fun people(): List<Person> = readableDatabase.rawQuery("SELECT * FROM people ORDER BY name",null).use { c -> buildList { while(c.moveToNext()) add(Person(c.getLong(0),c.getString(1)?:"",c.getString(2)?:"",c.getString(3)?:"",c.getString(4)?:"")) } }
    fun deletePerson(id: Long) { writableDatabase.delete("people","id=?",arrayOf(id.toString())) }
    fun patterns(): List<Pattern> = readableDatabase.rawQuery("SELECT * FROM patterns ORDER BY id",null).use { c -> buildList { while(c.moveToNext()) add(Pattern(c.getLong(0),c.getString(1)?:"",c.getString(2)?:"",c.getString(3)?:"",c.getString(4)?:"")) } }
    fun logSend(adId: Long, recipient: String, channel: String, status: String) { writableDatabase.insert("send_logs",null,ContentValues().apply { put("ad_id",adId);put("recipient",recipient);put("channel",channel);put("status",status);put("created_at",System.currentTimeMillis()) }) }
    fun logsCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM send_logs",null).use { if(it.moveToFirst()) it.getInt(0) else 0 }
    fun adsCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM ads",null).use { if(it.moveToFirst()) it.getInt(0) else 0 }
    fun peopleCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM people",null).use { if(it.moveToFirst()) it.getInt(0) else 0 }
}
